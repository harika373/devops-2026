import React from "react";
import Cart from "./Cart";
import "./App.css";

function App() {
  return (
    <div>
      <Cart />
    </div>
  );
}

export default App;
