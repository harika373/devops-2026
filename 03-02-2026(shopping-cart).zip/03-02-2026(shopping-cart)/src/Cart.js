import React, { useState } from "react";
import CartItem from "./CartItem";

function Cart() {
  // ✅ Parent maintains items state
  const [items, setItems] = useState([
    { id: 1, name: "Wireless Headphones 🎧", price: 50, quantity: 0 },
    { id: 2, name: "Smart Watch ⌚", price: 80, quantity: 0 },
    { id: 3, name: "Gaming Mouse 🖱", price: 30, quantity: 0 },
    { id: 4, name: "Bluetooth Speaker 🔊", price: 60, quantity: 0 },
    { id: 5, name: "Laptop Backpack 🎒", price: 40, quantity: 0 },
  ]);

  // ✅ Increment Quantity
  const incrementQuantity = (id) => {
    setItems(
      items.map((item) =>
        item.id === id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      )
    );
  };

  // ✅ Decrement Quantity
  const decrementQuantity = (id) => {
    setItems(
      items.map((item) =>
        item.id === id && item.quantity > 0
          ? { ...item, quantity: item.quantity - 1 }
          : item
      )
    );
  };

  // ✅ Total Price Calculation (Bonus)
  const totalPrice = items.reduce(
    (total, item) => total + item.price * item.quantity,
    0
  );

  return (
    <div className="cart-container">
      <h1 className="title">🛒 Shopping Cart</h1>

      {/* Render 5 Items */}
      <div className="items-grid">
        {items.map((item) => (
          <CartItem
            key={item.id}
            item={item}
            increment={incrementQuantity}
            decrement={decrementQuantity}
          />
        ))}
      </div>

      {/* Total Price */}
      <h2 className="total">
        Total Price: <span>${totalPrice}</span>
      </h2>
    </div>
  );
}

export default Cart;
