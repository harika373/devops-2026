import React from "react";

function CartItem({ item, increment, decrement }) {
  return (
    <div className="cart-card">
      <h2>{item.name}</h2>

      <p>
        <b>Price:</b> ${item.price}
      </p>

      <p>
        <b>Quantity:</b> {item.quantity}
      </p>

      {/* Buttons inside child */}
      <div className="buttons">
        <button
          onClick={() => increment(item.id)}
          className="btn add"
        >
          +
        </button>

        {/* Bonus: Disable decrement at 0 */}
        <button
          onClick={() => decrement(item.id)}
          className="btn remove"
          disabled={item.quantity === 0}
        >
          -
        </button>
      </div>
    </div>
  );
}

export default CartItem;
